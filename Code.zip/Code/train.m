% You can change anything you want in this script.
% It is provided just for your convenience.
clear; clc; close all;

img_path = './train/';
class_num = 30;
img_per_class = 60;
img_num = class_num .* img_per_class;


%feat_dim = size(feature_extraction(rgb2gray(im2single(imread('./val/Balloon/329060.JPG')))),2);

folder_dir = dir(img_path);
feature_train = [];
featureSizeImagesall=[];
%feat_train = zeros(img_num,feat_dim);
label_train = zeros(class_num,1);
%trainingImages= cell(class_num * img_per_class,1);
%trainingLabel= cell(class_num * img_per_class ,1);

for i = 1:length(folder_dir)-2
    
    img_dir = dir([img_path,folder_dir(i+2).name,'/*.JPG']);
    if isempty(img_dir)
        img_dir = dir([img_path,folder_dir(i+2).name,'/*.BMP']);
    end
    
    label_train((i-1)*img_per_class+1:i*img_per_class) = i;
   % label_train(i) = i;
    
    %featureSizeperCat = 0;
    for j = 1:length(img_dir)        
        img = imread([img_path,folder_dir(i+2).name,'/',img_dir(j).name]);
        %image = im2double(img);
        %image = rgb2gray(image);
        feat_train = feature_extraction_training(img);
       % featureSizeperCat = featureSizeperCat+size(feat_train,1);
        
     
       feature_train = [feature_train;feat_train];
        %label_train{(i-1)*img_per_class + j} = i;
    featureSizeImagesall{(i-1)*img_per_class + j} = size(feat_train,1);
        %trainingImages{(i-1)*img_per_class + j} = fullfile([img_path,folder_dir(i+2).name,'/',img_dir(j).name]);
    end
    %featureSizeImagesall{i} = featureSizeperCat;
    
  
end
if ~exist('dictionary.mat', 'file')
    %[idx,centroid] = kmeans(feature_train,50,'emptyaction','singleton','onlinephase','off','options',options);
    [idx,centroid] = kmeans(feature_train,63,'MaxIter',5000);
%     [~,centroid,~] = simpleKmeans(data,cNum,15,0,1e-4);
%     [centroid,~]=vl_kmeans(data, cNum, 'verbose',  'algorithm','elkan');
%[idx,centers ] = kmeans(single(feature_train), 1500);
dictionary = centroid;
save('idx.mat', 'idx');
save('dictionary.mat', 'dictionary');
end
 load('idx.mat')
% Histogram calculation
histo_all=[];

% for i = 1:img_num
%     img =  imread(trainingImages{i});
%          
%     features = feature_extraction(img);
%     dist=zeros(size(dictionary,1),1);
%     for j=1:size(features,1)
%     trainimgHist = features(j,:);
%     for k=1:size(dictionary,1)
%         dist(k) = sqrt(sum((dictionary(k,:) - trainimgHist) .^ 2));
%     end
%     [disSorted,idx]=sort(dist);
%     %predict_label(i) = floor(idx(1)/60)+1;
%     idx = idx(1:10);
% 
%     end
% %     histo = zeros(1,50);
% %     for e= 1:size(idx,1)
% %      histo(1,idx(e))= histo(1,idx(e))+1;   
% %     end
%     %normalization
%       histo = hist(double(idx), 50);
%    nor_hist = histo ./ sum(histo);
%    histo_all=[histo_all;nor_hist];
% end
inx=0;
for h=1:img_num
    histo = zeros(1,63);
    e_Index =inx+featureSizeImagesall{h}; 
    s_Index = inx+1;
    for e= s_Index:e_Index
     histo(1,idx(e))= histo(1,idx(e))+1;   
    end
    %normalization
   nor_hist = histo ./ sum(histo);
   inx=inx+featureSizeImagesall{h};
   histo_all=[histo_all;nor_hist];
end
% for h=1:class_num
%     histo = zeros(1,41);
%     for e= 1:featureSizeImagesall{h}
%      histo(1,idx(e))= histo(1,idx(e))+1;   
%     end
%     %normalization
%    nor_hist = histo ./ sum(histo);
%    histo_all=[histo_all;nor_hist];
% end

%if ~exist('bag_of_words_train.mat', 'file')
%bag_of_words_train = bagOfFeatures(img_num,trainingImages,200);

save('model.mat', 'histo_all','label_train');
%save('model.mat','feat_train','label_train');


