function feat = feature_extraction(img)
% Output should be a fixed length vector [1*dimension] for a single image. 
% Please do NOT change the interface.
       % feat=[];
       %feat = zero([1,100]); % dummy, replace this with your algorithm
       % Parameters placed based on documentation of detectSURFFeatures and
       % extractFeatures
       load('dictionary.mat')
       load('model.mat')
       name_detect = 'MetricThreshold';
       value_detect = 500;
       name_SURF = 'SURFSize';
       value_SURF = 128;
       strong_pts= 200;
       %   imaged = im2double(img);
       %[~,~,c] = size(imaged);
       %Img = rgb2gray(repmat(imaged,[1,1,4-c]));
       image = im2single(img);
        image = rgb2gray(image); 
        %image = rgb2gray(image);
       interestingPoints= detectSURFFeatures(image,name_detect,value_detect);
       [feat,points] = extractFeatures(image,interestingPoints.selectStrongest(strong_pts),name_SURF,value_SURF);
       %descriptor = extractFeatures(image,interestingPoints.selectStrongest(strong_pts),'Method','surf');
%       feat=  num2cell(points.selectStrongest(100).Orientation,[1 100]);
        
         length_query =size(feat,1); 
 length_train_his=size(dictionary,1);
 test_euli_distance= zeros(1,length_train_his);
     for l=1:length_query
         %e_dist = sqrt(sum((dictionary - feat(l,:)) .^ 2));
        e_dist = sqrt(sum((bsxfun(@minus, dictionary, feat(l,:))).^2,2));
         [~,idx]=min(e_dist);
         test_euli_distance(idx)=test_euli_distance(idx)+1;
     end
         % normailzed Histo
         feat = test_euli_distance/ sum(test_euli_distance);
%end

%   histogram_for_test_image = zeros(1, size(dictionary,1));
%         for r=1:size(feat,1)
%             a = sqrt(sum((bsxfun(@minus, dictionary, feat(r,:))).^2,2));
%             [m, I] = min(a);
%             histogram_for_test_image(I) = histogram_for_test_image(I)+1;
%         end
%         histogram_for_test_image=histogram_for_test_image/sum(histogram_for_test_image);
%         %list_of_hist_features = [list_of_hist_features; histogram_for_test_image];
%         feat=histogram_for_test_image;
       
end