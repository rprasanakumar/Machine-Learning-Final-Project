function predict_label = your_kNN(features)
% Output should be a fixed length vector [num of img, 1]. 
% Please do NOT change the interface.
img_num = 30*20;
%load('dictionary.mat') 
load('training_model.mat')
%cluster=KDTreeSearcher(dictionary);
%refdictionarysize = size(dictionary,1);
% K neightest Neightbor implemantation
% 
%     [imagesize_row,imagesize_column]=size(features);
%       IDX = zeros(imagesize_row,200);
%      for j = 1:imagesize_row
%         
%          dist = zeros(refdictionarysize,1);
%          for k=1:imagesize_column
%             dist = dist+abs(dictionary(:,k)-features(j,k));
%          end
%         [distance,index]=sort(dist);
%          IDX(k,:)=index(1:200);
%      end
%labelSize = size(trainingLabel,1);
%training_label = cell(0,labelSize);
% for n=1:labelSize
%     training_label{n}=trainingLabel(n);   
% end
% training_label = cell2mat(label_train);
model = fitcknn(image_feats, label_trains,'NumNeighbors',19);
%features = single(features')
% classerror= kfoldLoss(CVKNNMdl,'Mode','individual');
 predicted_categories = predict(model, features);
predict_label = predicted_categories; %dummy. replace it with your own code
%euclidean dist between histograms
% predict_labels=[]
% e_dist=  pdist2(histo_all,test_hist);
% %complement_edist = e_dist';
% size_test_hist = size(test_hist,1);
% for i=1:size_test_hist
%     [D,idx] = min(e_dist(i,:));
%     lbel = training_label(idx,1);
%     predict_labels=[predict_labels;lbel];
% end
% predict_label=predict_labels;
%%%%%%%%%%%%%%%%%%%
end