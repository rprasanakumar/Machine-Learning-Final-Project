function feat = feature_extraction(img)
% Output should be a fixed length vector [1*dimension] for a single image. 
% Please do NOT change the interface.
       % feat=[];
       %feat = zero([1,100]); % dummy, replace this with your algorithm
       % Parameters placed based on documentation of detectSURFFeatures and 
       % extractFeatures
       name_detect = 'MetricThreshold';
       value_detect = 500;
       name_SURF = 'SURFSize';
       value_SURF = 128;
       strong_pts= 400;
         % imaged = im2double(img);
       %[~,~,c] = size(imaged);
       %Img = rgb2gray(repmat(imaged,[1,1,4-c]));
       image = im2single(img);
        %image = rgb2gray(image); 
        image = rgb2gray(image);
       interestingPoints= detectSURFFeatures(image,name_detect,value_detect);
       [feat,points] = extractFeatures(image,interestingPoints.selectStrongest(strong_pts),name_SURF,value_SURF);
%       feat=  num2cell(points.selectStrongest(100).Orientation,[1 100]);
       
end